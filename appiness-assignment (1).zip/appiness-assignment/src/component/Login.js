import React, { Component } from 'react';

class Login extends Component {
    constructor(props) {
        super(props);
        this.state = {
            user_name: "",
            password: "",
            isSubmit: false,
            isEmailValid: false
        }
    }

    handleLogin = () => {
        const { user_name, password, isEmailValid } = this.state;
        this.setState({ isSubmit: true });

        if (user_name !== "" && password !== "" && isEmailValid) {
            window.localStorage.setItem("islogin", true)
            this.props.history.push('/userlist');
        }
    }

    handleEmailValidation = (e) => {
        var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
        if (reg.test(e.target.value)) {
            this.setState({ isEmailValid: true })
        } else {
            this.setState({ isEmailValid: false })
        }
    }
    render() {
        return (
            <div className="container mt-5 justify-content-center">
                <div className="card custom-card">
                    <div className="card-body">
                        <h3>Welcome to login Page</h3>

                        <input className="form-control mt-3" placeholder="Enter you email"
                            onChange={(e) => { this.setState({ user_name: e.target.value }); this.handleEmailValidation(e) }} />
                        {this.state.user_name === "" && this.state.isSubmit && <div className="text-error"> Please enter email id</div>}

                        {this.state.user_name !== "" && !this.state.isEmailValid && <div className="text-error">Please enter Valid email id</div>}

                        <input className="form-control mt-3" placeholder="Password" type="password"
                            onChange={(e) => { this.setState({ password: e.target.value }) }} />

                        {this.state.password === "" && this.state.isSubmit && <div className="text-error"> Please enter password </div>}
                        <div className='d-flex justify-content-center'>
                        <button className="btn btn-warning mt-3" onClick={this.handleLogin}>Log in </button>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

export default Login;