import React, { Component } from 'react';

class Header extends Component {
    handleLogout = () =>{
        window.localStorage.removeItem('islogin')
        this.props.history.push('/')
    }
    render() {
        console.log(this.props);
        return (
            <div>
                <nav className="navbar navbar-light bg-dark mb-3">
                    <div className="container-fluid">
                        <a className="navbar-brand text-white">Appiness</a>
                        <button className="btn btn-primary" onClick={this.handleLogout}>Logout</button>
                    </div>
                </nav>
            </div>
        )
    }
}

export default Header;