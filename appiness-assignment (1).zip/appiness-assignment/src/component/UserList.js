import React, { Component } from 'react';
import axios from 'axios'
import Header from './Header';
class UserList extends Component{
    constructor(props){
        super(props)
        this.state = {
            userData :[]
        }
    }
    componentWillMount(){
        let Login = window.localStorage.getItem('islogin')
        if(Login === null ){
            this.props.history.push('/')
        }
    }
    componentDidMount(){
        axios.get('./userData.json')
        .then(res =>{
            if(res&&res.data&& res.data.user){
                this.setState({userData: res.data.user})
            }
        })
    }
    render(){
    const { userData} = this.state;
        return(
            <div className="container-fluid">
                <Header {...this.props}/>
                <table className="table table-bordered">
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th>Name</th>
                            <th>Phone No</th>
                            <th>Email</th>
                            <th>Age</th>
                            <th>Gender</th>
                        </tr>
                    </thead>
                    <tbody>
                       {
                           userData&&userData.length>0&&(
                            userData.map((data, index)=>{
                                return(
                                    <tr className="" key={index}>
                                        <td>{data.id}</td>
                                        <td>{data.name}</td>
                                        <td>{data.phoneNo}</td>
                                        <td>{data.email}</td>
                                        <td>{data.age}</td>
                                        <td>{data.gender}</td>
                                    </tr>
                                )
                            }) 
                           )
                       }
                    </tbody>
                </table>
            </div>
        )
    }
}
export default UserList;