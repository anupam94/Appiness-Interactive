import { BrowserRouter as Router, Route } from 'react-router-dom';
import "bootstrap/dist/css/bootstrap.css";
import './App.css';
import Login from './component/Login';
import UserList from './component/UserList';

function App() {
  return (
    <Router>
      <div className="App">
        <Route exact path="/" component={Login} />
        <Route exact path="/userlist" component={UserList} />
      </div>
    </Router>
  );
}
export default App;
